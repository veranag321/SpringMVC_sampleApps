Why is this empty?

If you prefer not to use less.js client-side, you can use the build tools in Kickstrap/build and your stylesheets will be automatically generated here.