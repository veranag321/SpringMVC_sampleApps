package com.sndt.service.test;




import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.jupiter.api.function.Executable;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import static org.junit.jupiter.api.Assertions.assertThrows;

import com.sndt.dto.Employee;
import com.sndt.dto.Lead;
import com.sndt.dto.RetrieveResultInput;
import com.sndt.dto.StoreRequest;
import com.sndt.entity.Eula;
import com.sndt.entity.Request;
import com.sndt.entity.Result;
import com.sndt.repository.EulaRepository;
import com.sndt.repository.RequestRepository;
import com.sndt.repository.ResultRepository;

import com.sndt.service.StoreRequestService;

import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class TestStoreReuestService {
	
	@Mock
	EulaRepository eulaRepository;
	
	@Mock
	RequestRepository requestRepository;
	
	@Mock
	ResultRepository resultRepository;
	
	@InjectMocks
	StoreRequestService srs;
	
	StoreRequest storeRequest=null;	
	
	private Employee employee = null;
	private Lead lead = null;
	private Eula eula = new Eula();
	private Request request = new Request();
	private Result result = new Result();
	
	private RetrieveResultInput retrieveResultInput = null;
	
	@Test
	public void saveRequestDetailsEmployeeNotNullTest() throws RuntimeException{
		//srs = new StoreRequestService();
		storeRequest = getStoreRequest();
		//eula.setVersion(storeRequest.getVersion());
		
		when(eulaRepository.save(eula)).thenReturn(eula);
		
		when(requestRepository.save(request)).thenReturn(request);
		
		when(resultRepository.save(result)).thenReturn(result);
		
		boolean result = srs.saveRequestDetails(storeRequest);
        
		//(	srs.saveRequestDetails(storeRequest));
		//AssertE
		assertEquals(true,result);
		
	}

	//@Ignore
	@Test
	public void saveRequestDetailsEmployeeNullTest() throws RuntimeException{
		
		//storeRequest = new StoreRequest();
		storeRequest = getStoreRequest();
		storeRequest.setEmployee(null);
		boolean result  = srs.saveRequestDetails(storeRequest);
		
		assertEquals(false,result);
	}
	
	
	//@Rule
	//public ExpectedException expectedException = ExpectedException.none();
	
	@Test//(expected = NullPointerException.class)
	public void saveRequestDetailsEmployeeExceptionTest (){

		storeRequest = getStoreRequest();
		storeRequest.setLead(null);	
		//srs.saveRequestDetails(storeRequest);
	/*	
		Throwable exception = assertThrows(NullPointerException.class, new Executable() {
			
			@Override
			public void execute() throws Throwable {
				// TODO Auto-generated method stub
				srs.saveRequestDetails(storeRequest);
				
			}
		});
	//	System.out.println("...."+exception.getMessage());
		assertEquals(null, exception.getMessage());*/
        
	//	Mockito.doThrow(new NullPointerException()).when(srs).saveRequestDetails(storeRequest);
		 //expectedException.expectMessage("The expected message");
		 
		 //expectedException.expect(NullPointerException.class);
		   // CustomClass myClass= mock(CustomClass.class);
		   // doThrow(new MyException("constructor failed")).when(myClass);  

		//    given(srs.saveRequestDetails(storeRequest)).willThrow(new NullPointerException("The expected message"));
			
	//	when( srs.saveRequestDetails(storeRequest)).thenThrow(new NullPointerException());
				
	 try {
		 srs.saveRequestDetails(storeRequest);
	    } catch (NullPointerException e) {
	        assertEquals(null, e.getMessage());
	    }
	
	}
	
	public void findRequestDetailsTest(){
		
		
		
	}

	
	private StoreRequest getStoreRequest(){
		
		employee = new Employee();
		employee.setEmailAddress("test@gmail.com");
		employee.setId("1");
		employee.setName("Tester1");
		employee.setPhoneNumber("1234567890");
		
		lead = new Lead();
		lead.setEmailAddress("test2@gmail.com");
		lead.setFirstName("Tester 2");
		lead.setId("2");
		lead.setLastName("Tester 2 last name");
		
		storeRequest = new StoreRequest();
		storeRequest.setEmployee(employee);
		storeRequest.setLead(lead);
		storeRequest.setVersion(1L);
		
		
		return storeRequest;
		
	}
	
	private RetrieveResultInput getRetrieveResultInput(){
		
		
		 retrieveResultInput = new RetrieveResultInput();
		 final Lead lead = new Lead();
		 lead.setId("1");
		 retrieveResultInput.setLead(lead);
		 
		 
		return retrieveResultInput;
				
	}
	

}
