package com.sndt.entity;

import java.sql.Timestamp;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
@Entity
@Table(name = "sndt_resultsports")
public class ResultsPorts {
	private Long id;
	private Long result_id;
	private Long port_id;
	private boolean status;
	private Result result;
	private PortsToTest portstotest;
	private boolean active;
    private String createdby;
    private Timestamp createddatetime;
    private String modifiedby;
    private Timestamp modifieddatetime;
	public ResultsPorts(){}
	
	public ResultsPorts(Result result){	
		this.result=result;
	}
	public ResultsPorts(Result result,PortsToTest portstotest){	
		this.result=result;
		this.portstotest=portstotest;
	}
	public ResultsPorts(PortsToTest portstotest){	
		this.portstotest=portstotest;
	}
	public ResultsPorts(Long id,Result result){
		this.id=id;
		this.result=result;
	}
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}	
	@ManyToOne(fetch=FetchType.EAGER,cascade = CascadeType.PERSIST)
	@JoinColumn(name = "port_id",insertable=false, updatable=false)
	public PortsToTest getPortstotest() {
		return portstotest;
	}

	public void setPortstotest(PortsToTest portstotest) {
		this.portstotest = portstotest;
	}

	public Long getResult_id() {
		return result_id;
	}
	public void setResult_id(Long result_id) {
		this.result_id = result_id;
	}
	public Long getPort_id() {
		return port_id;
	}
	public void setPort_id(Long port_id) {
		this.port_id = port_id;
	}
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	@ManyToOne(fetch=FetchType.EAGER,cascade = CascadeType.PERSIST)
	@JoinColumn(name = "result_id",insertable=false, updatable=false)
	public Result getResult() {
		return result;
	}
	public void setResult(Result result) {
		this.result = result;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public String getCreatedby() {
		return createdby;
	}

	public void setCreatedby(String createdby) {
		this.createdby = createdby;
	}

	public Timestamp getCreateddatetime() {
		return createddatetime;
	}

	public void setCreateddatetime(Timestamp createddatetime) {
		this.createddatetime = createddatetime;
	}

	public String getModifiedby() {
		return modifiedby;
	}

	public void setModifiedby(String modifiedby) {
		this.modifiedby = modifiedby;
	}

	public Timestamp getModifieddatetime() {
		return modifieddatetime;
	}

	public void setModifieddatetime(Timestamp modifieddatetime) {
		this.modifieddatetime = modifieddatetime;
	}	
	
}
