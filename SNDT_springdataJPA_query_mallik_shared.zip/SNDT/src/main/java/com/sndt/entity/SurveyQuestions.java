package com.sndt.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
@JsonIgnoreProperties
@Entity
@Table(name = "sndt_surveyquestions")
public class SurveyQuestions implements Serializable{
	private Long question_id;
	private String question;
	private boolean active;
    private String createdby;
    private Timestamp createddatetime;
    private String modifiedby;
    private Timestamp modifieddatetime;
	private Set<SurveyAnswers> surveyanswers;
	private LeadSurveyAnswers leadsurveyanswers;
	public SurveyQuestions() {

	}

	public SurveyQuestions(Long question_id) {
		this.question_id = question_id;
	}
	@Id
	//@GeneratedValue(strategy = GenerationType.AUTO)
	public Long getQuestion_id() {
		return question_id;
	}

	public void setQuestion_id(Long question_id) {
		this.question_id = question_id;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}
	@OneToMany(mappedBy = "surveyquestions", fetch = FetchType.LAZY, cascade = CascadeType.PERSIST)
	public Set<SurveyAnswers> getSurveyanswers() {
		return surveyanswers;
	}

	public void setSurveyanswers(Set<SurveyAnswers> surveyanswers) {
		this.surveyanswers = surveyanswers;
	}
	@OneToOne(mappedBy = "surveyquestions",cascade = CascadeType.ALL, orphanRemoval = true)
	public LeadSurveyAnswers getLeadsurveyanswers() {
		return leadsurveyanswers;
	}

	public void setLeadsurveyanswers(LeadSurveyAnswers leadsurveyanswers) {
		this.leadsurveyanswers = leadsurveyanswers;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public String getCreatedby() {
		return createdby;
	}

	public void setCreatedby(String createdby) {
		this.createdby = createdby;
	}

	public Timestamp getCreateddatetime() {
		return createddatetime;
	}

	public void setCreateddatetime(Timestamp createddatetime) {
		this.createddatetime = createddatetime;
	}

	public String getModifiedby() {
		return modifiedby;
	}

	public void setModifiedby(String modifiedby) {
		this.modifiedby = modifiedby;
	}

	public Timestamp getModifieddatetime() {
		return modifieddatetime;
	}

	public void setModifieddatetime(Timestamp modifieddatetime) {
		this.modifieddatetime = modifieddatetime;
	}

}
