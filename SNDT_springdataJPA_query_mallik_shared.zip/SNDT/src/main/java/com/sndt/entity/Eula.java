package com.sndt.entity;
import java.sql.Timestamp;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
@Entity
@Table(name = "sndt_eula")
public class Eula {	
	private Long eula_id;
	private Long version;
	private Timestamp startdate;
	private Timestamp enddate;
	private String eulatext;
	private boolean active;
    private String createdby;
    private Timestamp createddatetime;
    private String modifiedby;
    private Timestamp modifieddatetime;
	private Set<Result> result;
	public Eula(){}
	public Eula(Long eula_id){
		this.eula_id=eula_id;
	}
	
	public Timestamp getStartdate() {
		return startdate;
	}
	public void setStartdate(Timestamp startdate) {
		this.startdate = startdate;
	}
	public Timestamp getEnddate() {
		return enddate;
	}
	public void setEnddate(Timestamp enddate) {
		this.enddate = enddate;
	}
	public String getEulatext() {
		return eulatext;
	}
	public void setEulatext(String eulatext) {
		this.eulatext = eulatext;
	}
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Long geteula_id() {
		return eula_id;
	}
	public void seteula_id(Long eula_id) {
		this.eula_id = eula_id;
	}
	public Long getVersion() {
		return version;
	}
	public void setVersion(Long version) {
		this.version = version;
	}	
	
	@OneToMany(mappedBy = "eula", cascade = CascadeType.ALL)
	public Set<Result> getResult() {
		return result;
	}
	public void setResult(Set<Result> result) {
		this.result = result;
	}
	
	public boolean isActive() {
		return active;
	}
	public void setActive(boolean active) {
		this.active = active;
	}
	public String getCreatedby() {
		return createdby;
	}
	public void setCreatedby(String createdby) {
		this.createdby = createdby;
	}
	public Timestamp getCreateddatetime() {
		return createddatetime;
	}
	public void setCreateddatetime(Timestamp createddatetime) {
		this.createddatetime = createddatetime;
	}
	public String getModifiedby() {
		return modifiedby;
	}
	public void setModifiedby(String modifiedby) {
		this.modifiedby = modifiedby;
	}
	public Timestamp getModifieddatetime() {
		return modifieddatetime;
	}
	public void setModifieddatetime(Timestamp modifieddatetime) {
		this.modifieddatetime = modifieddatetime;
	}
	
}
