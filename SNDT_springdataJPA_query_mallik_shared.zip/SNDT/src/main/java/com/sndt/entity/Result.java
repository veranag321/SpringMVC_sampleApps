package com.sndt.entity;
import java.sql.Timestamp;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
@Entity
@Table(name = "sndt_result")
public class Result {
	private Long result_id;	
	private Long request_id;	
	private String testid;
	private Long eula_id;
	private String clientip;
	private Timestamp testdate;
	private String bandwidthdown;
	private String bandwidthup;
	private Long latency;
	private Request request;
	private Eula eula;
	private boolean active;
    private String createdby;
    private Timestamp createddatetime;
    private String modifiedby;
    private Timestamp modifieddatetime;
	private Set<ResultsPorts> resultports;  
	private Set<LeadSurveyAnswers> leadsurveyanswers;
	
	public Result(){}
	public Result(Request request){		
		this.request=request;
	}
	public Result(Long result_id,Request request){
		this.result_id=result_id;
		this.request=request;
	}
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Long getResult_id() {
		return result_id;
	}
	public void setResult_id(Long result_id) {
		this.result_id = result_id;
	}
	
	public String getTestid() {
		return testid;
	}
	public void setTestid(String testid) {
		this.testid = testid;
	}
	
	public void setBandwidthdown(String bandwidthdown) {
		this.bandwidthdown = bandwidthdown;
	}
	
	public Long getEula_id() {
		return eula_id;
	}
	public void setEula_id(Long eula_id) {
		this.eula_id = eula_id;
	}
	public String getClientip() {
		return clientip;
	}
	public void setClientip(String clientip) {
		this.clientip = clientip;
	}
	public Timestamp getTestdate() {
		return testdate;
	}
	public void setTestdate(Timestamp testdate) {
		this.testdate = testdate;
	}
	public String getBandwidthdown() {
		return bandwidthdown;
	}
	
	public String getBandwidthup() {
		return bandwidthup;
	}
	public void setBandwidthup(String bandwidthup) {
		this.bandwidthup = bandwidthup;
	}
	public Long getLatency() {
		return latency;
	}
	public void setLatency(Long latency) {
		this.latency = latency;
	}	
	
	@ManyToOne(fetch=FetchType.EAGER,cascade = CascadeType.PERSIST)
	@JoinColumn(name = "request_id",insertable=false, updatable=false)
	public Request getRequest() {
		return request;
	}
	public void setRequest(Request request) {
		this.request = request;
	}
	@ManyToOne(fetch=FetchType.EAGER,cascade = CascadeType.PERSIST)
	@JoinColumn(name = "eula_id",insertable=false, updatable=false)
	public Eula getEula() {
		return eula;
	}
	public void setEula(Eula eula) {
		this.eula = eula;
	}
	@OneToMany(mappedBy = "result", fetch = FetchType.LAZY, cascade = CascadeType.PERSIST)
	public Set<ResultsPorts> getResultports() {
		return resultports;
	}
	public void setResultports(Set<ResultsPorts> resultports) {
		this.resultports = resultports;
	}
	@OneToMany(mappedBy = "result", fetch = FetchType.LAZY, cascade = CascadeType.PERSIST)
	public Set<LeadSurveyAnswers> getLeadsurveyanswers() {
		return leadsurveyanswers;
	}
	public void setLeadsurveyanswers(Set<LeadSurveyAnswers> leadsurveyanswers) {
		this.leadsurveyanswers = leadsurveyanswers;
	}
	public boolean isActive() {
		return active;
	}
	public void setActive(boolean active) {
		this.active = active;
	}
	public String getCreatedby() {
		return createdby;
	}
	public void setCreatedby(String createdby) {
		this.createdby = createdby;
	}
	public Timestamp getCreateddatetime() {
		return createddatetime;
	}
	public void setCreateddatetime(Timestamp createddatetime) {
		this.createddatetime = createddatetime;
	}
	public String getModifiedby() {
		return modifiedby;
	}
	public void setModifiedby(String modifiedby) {
		this.modifiedby = modifiedby;
	}
	public Timestamp getModifieddatetime() {
		return modifieddatetime;
	}
	public void setModifieddatetime(Timestamp modifieddatetime) {
		this.modifieddatetime = modifieddatetime;
	}
	public Long getRequest_id() {
		return request_id;
	}
	public void setRequest_id(Long request_id) {
		this.request_id = request_id;
	}	
	
}
