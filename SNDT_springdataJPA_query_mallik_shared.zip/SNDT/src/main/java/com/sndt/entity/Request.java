package com.sndt.entity;
import java.sql.Timestamp;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
@Entity
@Table(name = "sndt_request")
public class Request {	
	private Long request_id;
	private String leadid;
	private String leademailaddress;
	private String leadfirstname;
    private String leadlastname;   
    private String clientApp;
    private String empid;
    private String empname;
    private String empemailaddress;
    private String empphonenumber;
    private String testid;
    private Timestamp testdate;
    private Set<Result> result;
    private boolean active;
    private String createdby;
    private Timestamp createddatetime;
    private String modifiedby;
    private Timestamp modifieddatetime;
    public Request(){
    	
    }
    public Request(Long request_id){
    	this.request_id=request_id;
    }
    
    public String getClientApp() {
		return clientApp;
	}
	public void setClientApp(String clientApp) {
		this.clientApp = clientApp;
	}
	//@EmbeddedId
	public String getLeadid() {
		return leadid;
	}
	public void setLeadid(String leadid) {
		this.leadid = leadid;
	}
	public String getLeademailaddress() {
		return leademailaddress;
	}
	public void setLeademailaddress(String leademailaddress) {
		this.leademailaddress = leademailaddress;
	}
	public String getLeadfirstname() {
		return leadfirstname;
	}
	public void setLeadfirstname(String leadfirstname) {
		this.leadfirstname = leadfirstname;
	}
	public String getLeadlastname() {
		return leadlastname;
	}
	public void setLeadlastname(String leadlastname) {
		this.leadlastname = leadlastname;
	}
	public String getEmpid() {
		return empid;
	}
	public void setEmpid(String empid) {
		this.empid = empid;
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public String getEmpemailaddress() {
		return empemailaddress;
	}
	public void setEmpemailaddress(String empemailaddress) {
		this.empemailaddress = empemailaddress;
	}
	public String getEmpphonenumber() {
		return empphonenumber;
	}
	public void setEmpphonenumber(String empphonenumber) {
		this.empphonenumber = empphonenumber;
	}
	//@Id
	public String getTestid() {
		return testid;
	}
	public void setTestid(String testid) {
		this.testid = testid;
	}
	public Timestamp getTestdate() {
		return testdate;
	}
	public void setTestdate(Timestamp testdate) {
		this.testdate = testdate;
	}
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Long getRequest_id() {
		return request_id;
	}
	public void setRequest_id(Long request_id) {
		this.request_id = request_id;
	}
	
	@OneToMany(mappedBy = "request", fetch = FetchType.LAZY, cascade = CascadeType.PERSIST)
	public Set<Result> getResult() {
		return result;
	}
	public void setResult(Set<Result> result) {
		this.result = result;
	}
	public boolean isActive() {
		return active;
	}
	public void setActive(boolean active) {
		this.active = active;
	}
	public String getCreatedby() {
		return createdby;
	}
	public void setCreatedby(String createdby) {
		this.createdby = createdby;
	}
	public Timestamp getCreateddatetime() {
		return createddatetime;
	}
	public void setCreateddatetime(Timestamp createddatetime) {
		this.createddatetime = createddatetime;
	}
	public String getModifiedby() {
		return modifiedby;
	}
	public void setModifiedby(String modifiedby) {
		this.modifiedby = modifiedby;
	}
	public Timestamp getModifieddatetime() {
		return modifieddatetime;
	}
	public void setModifieddatetime(Timestamp modifieddatetime) {
		this.modifieddatetime = modifieddatetime;
	}    
	
}
