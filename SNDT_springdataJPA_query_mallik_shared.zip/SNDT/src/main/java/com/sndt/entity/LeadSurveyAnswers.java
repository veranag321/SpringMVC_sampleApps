package com.sndt.entity;

import java.sql.Timestamp;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table(name = "sndt_leadsurveyanswers")
public class LeadSurveyAnswers {
	private Long id;
	private Long result_id;
	private Long question_id;
	private Long answer_id;
	private Result result;
	private SurveyQuestions surveyquestions;
	private SurveyAnswers surveyanswers;
	private boolean active;
    private String createdby;
    private Timestamp createddatetime;
    private String modifiedby;
    private Timestamp modifieddatetime;
	public LeadSurveyAnswers(){}
	
	public LeadSurveyAnswers(Result result){	
		this.result=result;
	}
	public LeadSurveyAnswers(SurveyQuestions surveyquestions){	
		this.surveyquestions=surveyquestions;
	}
	public LeadSurveyAnswers(Long id,Result result){
		this.id=id;
		this.result=result;
	}
	public LeadSurveyAnswers(Long id,Result result,SurveyQuestions surveyquestions,SurveyAnswers surveyanswers){
		this.id=id;
		this.result=result;
		this.surveyquestions=surveyquestions;
		this.surveyanswers=surveyanswers;
	}
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getResult_id() {
		return result_id;
	}

	public void setResult_id(Long result_id) {
		this.result_id = result_id;
	}

	public Long getQuestion_id() {
		return question_id;
	}

	public void setQuestion_id(Long question_id) {
		this.question_id = question_id;
	}

	public Long getAnswer_id() {
		return answer_id;
	}

	public void setAnswer_id(Long answer_id) {
		this.answer_id = answer_id;
	}
	@ManyToOne(fetch=FetchType.EAGER,cascade = CascadeType.PERSIST)
	@JoinColumn(name = "result_id",insertable=false, updatable=false)
	public Result getResult() {
		return result;
	}

	public void setResult(Result result) {
		this.result = result;
	}
	@OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "question_id",insertable=false, updatable=false)
	public SurveyQuestions getSurveyquestions() {
		return surveyquestions;
	}

	public void setSurveyquestions(SurveyQuestions surveyquestions) {
		this.surveyquestions = surveyquestions;
	}
	@OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "answer_id",insertable=false, updatable=false)
	public SurveyAnswers getSurveyanswers() {
		return surveyanswers;
	}

	public void setSurveyanswers(SurveyAnswers surveyanswers) {
		this.surveyanswers = surveyanswers;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public String getCreatedby() {
		return createdby;
	}

	public void setCreatedby(String createdby) {
		this.createdby = createdby;
	}

	public Timestamp getCreateddatetime() {
		return createddatetime;
	}

	public void setCreateddatetime(Timestamp createddatetime) {
		this.createddatetime = createddatetime;
	}

	public String getModifiedby() {
		return modifiedby;
	}

	public void setModifiedby(String modifiedby) {
		this.modifiedby = modifiedby;
	}

	public Timestamp getModifieddatetime() {
		return modifieddatetime;
	}

	public void setModifieddatetime(Timestamp modifieddatetime) {
		this.modifieddatetime = modifieddatetime;
	}
	
}
