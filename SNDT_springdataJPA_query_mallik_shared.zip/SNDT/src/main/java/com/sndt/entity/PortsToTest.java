package com.sndt.entity;

import java.sql.Timestamp;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
@Entity
@Table(name = "sndt_portstotest")
public class PortsToTest {
	private Long id;
	private Long port_id;
	private boolean active;
    private String createdby;
    private Timestamp createddatetime;
    private String modifiedby;
    private Timestamp modifieddatetime;
	private Set<ResultsPorts> resultports;
    public PortsToTest(){}
    public PortsToTest(Long port_id){
    	this.port_id=port_id;
    }
    @Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
	public Long getPort_id() {
		return port_id;
	}
	public void setPort_id(Long port_id) {
		this.port_id = port_id;
	}
	@OneToMany(mappedBy = "portstotest", fetch = FetchType.LAZY, cascade = CascadeType.PERSIST)
	public Set<ResultsPorts> getResultports() {
		return resultports;
	}
	public void setResultports(Set<ResultsPorts> resultports) {
		this.resultports = resultports;
	}
	public boolean isActive() {
		return active;
	}
	public void setActive(boolean active) {
		this.active = active;
	}
	public String getCreatedby() {
		return createdby;
	}
	public void setCreatedby(String createdby) {
		this.createdby = createdby;
	}
	public Timestamp getCreateddatetime() {
		return createddatetime;
	}
	public void setCreateddatetime(Timestamp createddatetime) {
		this.createddatetime = createddatetime;
	}
	public String getModifiedby() {
		return modifiedby;
	}
	public void setModifiedby(String modifiedby) {
		this.modifiedby = modifiedby;
	}
	public Timestamp getModifieddatetime() {
		return modifieddatetime;
	}
	public void setModifieddatetime(Timestamp modifieddatetime) {
		this.modifieddatetime = modifieddatetime;
	}
    
}

