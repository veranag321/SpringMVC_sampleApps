package com.sndt.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sndt.entity.SurveyQuestions;
@Repository
public interface SurveyQuestionsRepository extends JpaRepository<SurveyQuestions, Long>{
	@Query("SELECT r.question FROM SurveyQuestions r WHERE r.question_id= :question_id")
    public String findQById(@Param("question_id") Long question_id);	
	
	@Query("select SQ.question_id, SQ.question, SA.answer_id, SA.answer from SurveyQuestions SQ, SurveyAnswers SA where SQ.question_id=SA.question_id")
	public List<Object[]> findQandA();	
}