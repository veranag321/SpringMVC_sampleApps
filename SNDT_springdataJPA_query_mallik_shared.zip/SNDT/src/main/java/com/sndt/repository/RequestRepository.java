package com.sndt.repository;

import java.util.Date;
import java.sql.Timestamp;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sndt.entity.Request;
@Repository
public interface RequestRepository extends JpaRepository<Request, Long>{
	@Query("SELECT r FROM Request r WHERE r.leadid= :leadid")
    public List<Request> findRequestByLead(@Param("leadid") String leadid);
	
	@Query("SELECT r.testdate FROM Request r WHERE r.leadid= :leadid order by r.testdate desc")
    public List<Timestamp> findRequestByLeadTestDate(@Param("leadid") String leadid);
	
	@Query("SELECT r.testid FROM Request r WHERE r.leadid= :leadid and r.testdate= :testdate")
    public String findRequestByLeadDate(@Param("leadid") String leadid, @Param("testdate") Timestamp testdate);
	
}