package com.sndt.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sndt.entity.Result;
@Repository
public interface ResultRepository extends JpaRepository<Result, Long>{
	@Query("SELECT r FROM Result r WHERE r.testid= :testid and r.request_id=:request_id")
    public Result findResultByTest(@Param("testid") String testid, @Param("request_id") Long request_id);
	
}