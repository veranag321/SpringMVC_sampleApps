package com.sndt.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sndt.entity.Eula;
@Repository
public interface EulaRepository extends JpaRepository<Eula, Long>{
	
}