package com.sndt.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sndt.entity.SurveyAnswers;
import com.sndt.entity.SurveyQuestions;
@Repository
public interface SurveyAnswersRepository extends JpaRepository<SurveyAnswers, Long>{
	@Query("SELECT r.answer FROM SurveyAnswers r WHERE r.answer_id= :answer_id")
    public String findAnsById(@Param("answer_id") Long answer_id);
	
	@Query("select r FROM SurveyAnswers r where r.question_id=:question_id")
	public SurveyAnswers findAnswer(@Param("question_id") Long question_id);
}