package com.sndt.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sndt.entity.LeadSurveyAnswers;
@Repository
public interface LeadSurveyAnswersRepository extends JpaRepository<LeadSurveyAnswers, Long>{
	@Query("SELECT r FROM LeadSurveyAnswers r WHERE r.result_id= :result_id")
    public List<LeadSurveyAnswers> findQAByResult(@Param("result_id") Long result_id);
}