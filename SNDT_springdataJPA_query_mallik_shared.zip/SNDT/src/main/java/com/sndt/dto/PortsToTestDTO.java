package com.sndt.dto;

public class PortsToTestDTO {

}
