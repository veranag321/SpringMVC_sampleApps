package com.sndt.dto;

public class QandA {
	private int Q;
	private int A;
	public int getQ() {
		return Q;
	}
	public void setQ(int q) {
		Q = q;
	}
	public int getA() {
		return A;
	}
	public void setA(int a) {
		A = a;
	}
	
}
