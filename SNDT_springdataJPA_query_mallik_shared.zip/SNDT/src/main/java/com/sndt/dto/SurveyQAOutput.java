package com.sndt.dto;

import java.util.List;

public class SurveyQAOutput {
	private List<SurveyQA> surveyQA;	
}
