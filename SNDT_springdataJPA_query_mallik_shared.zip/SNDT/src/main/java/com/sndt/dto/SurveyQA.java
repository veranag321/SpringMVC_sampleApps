package com.sndt.dto;
import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class SurveyQA {
	private String question_id;
	private String question;
	private String answer_id;
	private String answer;
	@Id
	public String getQuestion_id() {
		return question_id;
	}
	public void setQuestion_id(String question_id) {
		this.question_id = question_id;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public String getAnswer_id() {
		return answer_id;
	}
	public void setAnswer_id(String answer_id) {
		this.answer_id = answer_id;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	@Override
	public String toString(){
		return "=>"+question_id+"|"+question+"|"+answer_id+"|"+answer;
	}
}
