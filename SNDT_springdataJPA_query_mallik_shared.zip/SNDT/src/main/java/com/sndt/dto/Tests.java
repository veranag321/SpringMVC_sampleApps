package com.sndt.dto;

import java.sql.Timestamp;
import java.util.List;

public class Tests {
	private String id;
	private Employee employee;
	private Timestamp dateTime;
	private String ipAddress;
	private String uploadBandwidth;
	private String downloadbandwidth;
	private List<Ports> ports;
	private List<Survey> survey;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public Employee getEmployee() {
		return employee;
	}
	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
	public Timestamp getDateTime() {
		return dateTime;
	}
	public void setDateTime(Timestamp dateTime) {
		this.dateTime = dateTime;
	}
	public String getIpAddress() {
		return ipAddress;
	}
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}
	public String getUploadBandwidth() {
		return uploadBandwidth;
	}
	public void setUploadBandwidth(String uploadBandwidth) {
		this.uploadBandwidth = uploadBandwidth;
	}
	public String getDownloadbandwidth() {
		return downloadbandwidth;
	}
	public void setDownloadbandwidth(String downloadbandwidth) {
		this.downloadbandwidth = downloadbandwidth;
	}
	public List<Ports> getPorts() {
		return ports;
	}
	public void setPorts(List<Ports> ports) {
		this.ports = ports;
	}
	public List<Survey> getSurvey() {
		return survey;
	}
	public void setSurvey(List<Survey> survey) {
		this.survey = survey;
	}
	
}
