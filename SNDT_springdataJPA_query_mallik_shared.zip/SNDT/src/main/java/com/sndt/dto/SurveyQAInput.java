package com.sndt.dto;
import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class SurveyQAInput {
	private String questionsid;
	private String questiontext;
	private String answertext;
	private String answerid;
	@Id
	public String getQuestionsid() {
		return questionsid;
	}
	public void setQuestionsid(String questionsid) {
		this.questionsid = questionsid;
	}
	public String getQuestiontext() {
		return questiontext;
	}
	public void setQuestiontext(String questiontext) {
		this.questiontext = questiontext;
	}
	public String getAnswertext() {
		return answertext;
	}
	public void setAnswertext(String answertext) {
		this.answertext = answertext;
	}
	public String getAnswerid() {
		return answerid;
	}
	public void setAnswerid(String answerid) {
		this.answerid = answerid;
	}
	
}
