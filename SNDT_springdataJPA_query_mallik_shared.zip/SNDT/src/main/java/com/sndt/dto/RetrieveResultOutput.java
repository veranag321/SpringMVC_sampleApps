package com.sndt.dto;

import java.util.List;

public class RetrieveResultOutput {
	private LeadResult lead;
	private List<Tests> tests;
	public LeadResult getLead() {
		return lead;
	}
	public void setLead(LeadResult lead) {
		this.lead = lead;
	}
	public List<Tests> getTests() {
		return tests;
	}
	public void setTests(List<Tests> tests) {
		this.tests = tests;
	}
	
}
