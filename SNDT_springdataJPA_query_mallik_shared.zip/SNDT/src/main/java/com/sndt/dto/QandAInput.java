package com.sndt.dto;

import java.sql.Timestamp;
import java.util.List;

public class QandAInput {
	private String leadid;
	private String testdate;
	private String bandwidthdown;
	private String bandwidthup;
	private String clientip;
	private String latency;
	private List<Ports> ports;
	private List<SurveyQAInput> surveyQuestions;
	public String getLeadid() {
		return leadid;
	}
	public void setLeadid(String leadid) {
		this.leadid = leadid;
	}
	public String getTestdate() {
		return testdate;
	}
	public void setTestdate(String testdate) {
		this.testdate = testdate;
	}
	public String getBandwidthdown() {
		return bandwidthdown;
	}
	public void setBandwidthdown(String bandwidthdown) {
		this.bandwidthdown = bandwidthdown;
	}
	public String getBandwidthup() {
		return bandwidthup;
	}
	public void setBandwidthup(String bandwidthup) {
		this.bandwidthup = bandwidthup;
	}
	public String getClientip() {
		return clientip;
	}
	public void setClientip(String clientip) {
		this.clientip = clientip;
	}
	public String getLatency() {
		return latency;
	}
	public void setLatency(String latency) {
		this.latency = latency;
	}
	public List<Ports> getPorts() {
		return ports;
	}
	public void setPorts(List<Ports> ports) {
		this.ports = ports;
	}
	public List<SurveyQAInput> getSurveyQuestions() {
		return surveyQuestions;
	}
	public void setSurveyQuestions(List<SurveyQAInput> surveyQuestions) {
		this.surveyQuestions = surveyQuestions;
	}	
	
}
