package com.sndt.exception;

public class SNDTCustomException extends RuntimeException{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String exceptionMsg;
	private int opStatus;
	public SNDTCustomException(String exceptionMsg) {
	      this.exceptionMsg = exceptionMsg;
    }
	public SNDTCustomException(int opStatus, String exceptionMsg) {
		this.opStatus=opStatus;
	    this.exceptionMsg = exceptionMsg;
	}
	public int getOpStatus(){
		return opStatus;
	}
	public void setOpStatus(int opStatus) {
		this.opStatus = opStatus;
	}
	public String getExceptionMsg() {
		return this.exceptionMsg;
	}

	public void setExceptionMsg(String exceptionMsg) {
		this.exceptionMsg = exceptionMsg;
	}
}
