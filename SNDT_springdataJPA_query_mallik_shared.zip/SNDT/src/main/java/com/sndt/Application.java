package com.sndt;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.sndt.service.StoreRequestService;

@SpringBootApplication
@Configuration
@EnableWebMvc
//@EnableConfigServer
public class Application{	
	/*@Autowired
	StoreRequestService storeRequestService;*/
	public static void main(String[] args) {
		SpringApplication.run(Application.class);
	}	
	/*@Override
    public void run(String... strings) throws Exception {
		storeRequestService.findRequestDetails("SFDC");
	}*/
	/*@Override
    public void run(String... strings) throws Exception {
		ObjectMapper mapper = new ObjectMapper();
		String json1= "{\"version\" : 1,\"testId\" : \"GUID000028\",\"client\" :\"SFDC\",\"lead\" :{\"id\" :\"703123422\",\"firstName\" : \"John\",\"lastName\" : \"Smith\",\"emailAddress\" : \"joe@smith.com\"},\"employee\" : {\"id\" : \"dmitry@adt.com\",\"name\" : \"DimtryVaynriber\",\"emailAddress\" : \"dmitry@adt.com\",\"phoneNumber\" : \"9991231234\"}}";
		StoreRequest storeRequest = mapper.readValue(json1, StoreRequest.class);
		storeRequestService.savePersonDetails(storeRequest);
    }*/
	
}
