package com.sndt.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.sndt.dto.QandAInput;
import com.sndt.dto.RestResponse;
import com.sndt.dto.RetrieveResultInput;
import com.sndt.dto.RetrieveResultOutput;
import com.sndt.dto.StatusResult;
import com.sndt.dto.StoreRequest;
import com.sndt.dto.SurveyQA;
import com.sndt.exception.SNDTCustomException;
import com.sndt.service.StoreRequestService;
@RestController
public class SNDTController {	  
	@Autowired
	StoreRequestService storeRequestService; 
	private static final Logger logger = LoggerFactory.getLogger(SNDTController.class);
	private static final Logger LOGGER = LoggerFactory.getLogger(SNDTController.class);
    @RequestMapping(value="storeResult",method = RequestMethod.POST,produces = "application/json",consumes="application/json")
   // @ExceptionHandler({SNDTCustomException.class})
    public StatusResult storeResult(@RequestBody StoreRequest storeRequest) {
    	LOGGER.info("Inside storeResult controller");
    	boolean flag=storeRequestService.saveRequestDetails(storeRequest);
    	StatusResult result=null;
    	if(flag){
    		result=new StatusResult();
    		result.setStatus(HttpStatus.OK);
    		result.setMessage("Request accepted..");    		
    	}
    	return result;
    }
    @RequestMapping(value="retrieveResult",method = RequestMethod.POST,produces = "application/json",consumes="application/json")
  //  @ExceptionHandler({SNDTCustomException.class})
    public RetrieveResultOutput getResult(@RequestBody RetrieveResultInput resultInput) {
    	LOGGER.info("Inside getResult controller");
    	RetrieveResultOutput res=storeRequestService.findRequestDetails(resultInput);
    	if(null!=res){
    		return res;
    	}else {
    		throw new SNDTCustomException("Unable to Retrieve Result Data..."); 
    	}
    }   
    //  @ExceptionHandler({SNDTCustomException.class})
  @RequestMapping(value="getQandA",method = RequestMethod.GET,produces = "application/json")    
    public @ResponseBody RestResponse getQAByLeadTestDateValidation(@RequestParam String leadid){
    	LOGGER.info("Inside getQAByLeadTestDateValidation controller");
    	List<SurveyQA> res=storeRequestService.getQAByTestDateValidity(leadid);    	
    	if(null!=res && !res.isEmpty()){    		
    		return new RestResponse(200,"Got QA Successfull",res);
    	}else {
    		return new RestResponse(400,"Hours > 72",res);
    	}
    }
    /*@RequestMapping(value="getQandA",method = RequestMethod.GET,produces = "application/json")    
    @ExceptionHandler({SNDTCustomException.class})
    public @ResponseBody List<SurveyQA> getQAByLeadTestDateValidation(@RequestParam String leadid){
    	LOGGER.info("Inside getQAByLeadTestDateValidation controller");
    	List<SurveyQA> res=null;
    	res=storeRequestService.getQAByTestDateValidity(leadid);
    	if(null!=res && !res.isEmpty()){
    		return res;    		
    	}else {
    		return null;
    	}
    }*/
    @RequestMapping(value="storeQandA",method = RequestMethod.POST,produces = "application/json",consumes="application/json")
    @ExceptionHandler({SNDTCustomException.class})
    public StatusResult storeQandA(@RequestBody QandAInput qandAInput) {
    	LOGGER.info("Inside storeResult controller");
    	boolean flag=storeRequestService.saveQA(qandAInput);    	
    	StatusResult result=new StatusResult();
    	if(flag){
    		result.setStatus(HttpStatus.OK);
    		result.setMessage("Request accepted..");
    		return result;
    	}else {
    		throw new SNDTCustomException("Unable to Save Questions/Answers...");
    	}    	
    }
}
