package com.sndt.service;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.joda.time.DateTime;
import org.joda.time.Days;
import org.joda.time.LocalDate;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sndt.dto.Employee;
import com.sndt.dto.Lead;
import com.sndt.dto.LeadResult;
import com.sndt.dto.Ports;
import com.sndt.dto.QandAInput;
import com.sndt.dto.RetrieveResultInput;
import com.sndt.dto.RetrieveResultOutput;
import com.sndt.dto.StoreRequest;
import com.sndt.dto.Survey;
import com.sndt.dto.SurveyQA;
import com.sndt.dto.SurveyQAInput;
import com.sndt.dto.Tests;
import com.sndt.entity.Eula;
import com.sndt.entity.LeadSurveyAnswers;
import com.sndt.entity.PortsToTest;
import com.sndt.entity.Request;
import com.sndt.entity.Result;
import com.sndt.entity.ResultsPorts;
import com.sndt.entity.SurveyAnswers;
import com.sndt.entity.SurveyQuestions;
import com.sndt.exception.SNDTCustomException;
import com.sndt.repository.EulaRepository;
import com.sndt.repository.LeadSurveyAnswersRepository;
import com.sndt.repository.PortsToTestRepository;
import com.sndt.repository.RequestRepository;
import com.sndt.repository.ResultRepository;
import com.sndt.repository.ResultsPortsRepository;
import com.sndt.repository.SurveyAnswersRepository;
import com.sndt.repository.SurveyQuestionsRepository;

@Service
public class StoreRequestService {
	@Autowired
	private RequestRepository requestRepository;
	@Autowired
	private SurveyAnswersRepository surveyAnswersRepository;
	@Autowired
	private SurveyQuestionsRepository surveyQuestionsRepository;
	@Autowired
	private LeadSurveyAnswersRepository leadSurveyAnswersRepository;
	@Autowired
	private ResultsPortsRepository resultsPortsRepository;
	@Autowired
	private EulaRepository eulaRepository;
	@Autowired
	private ResultRepository resultRepository;	
	@Autowired
	private PortsToTestRepository portsToTestRepository;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(StoreRequestService.class);

	//@Transactional
	public boolean saveRequestDetails (StoreRequest storeRequest){		
		LOGGER.info("Inside saveRequestDetails method");
		boolean flag = false;
		try {
			Employee employee = storeRequest.getEmployee();
			Lead lead = storeRequest.getLead();
			final Request request = new Request();
			if (null != employee) {
				request.setEmpid(employee.getId());// 8
				request.setClientApp(storeRequest.getClient());// 3
				request.setEmpemailaddress(employee.getEmailAddress());// 10
				request.setEmpname(employee.getName());// 9
				request.setEmpphonenumber(employee.getPhoneNumber());// 11
				request.setLeademailaddress(lead.getEmailAddress());
				request.setLeadfirstname(lead.getFirstName());// 5
				request.setLeadid(lead.getId());// 4
				request.setLeadlastname(lead.getFirstName());// 6
				request.setLeademailaddress(lead.getEmailAddress());// 7
				request.setTestid(storeRequest.getTestId());// 2
			} else {
				LOGGER.info("No Employee Exists with given Store Request");
				return flag;
			}
			Timestamp date = new java.sql.Timestamp(new java.util.Date().getTime());
			request.setTestdate(date);			
			final Eula eula = new Eula();
			eula.setVersion(storeRequest.getVersion()); // 1
			eulaRepository.save(eula);
			LOGGER.info("Given Eula Details stored into Eula Table");
			Result result = new Result(eula.geteula_id(), request);			
			requestRepository.save(request);
			LOGGER.info("Given Request Data stored into Request table");
			result.setTestid(request.getTestid());
			result.setRequest_id(request.getRequest_id());
			result.setEula_id(eula.geteula_id());
			result.setTestdate(date);
			resultRepository.save(result);			
			LOGGER.info("Given Result Data stored into Result table");
			flag  = true;
			return flag;
		}catch (NullPointerException e) {
			LOGGER.debug("Unable to save given request details in Nullpointerexception");
			//e.printStackTrace();
			//return flag;
		}catch (Exception e) {
			LOGGER.debug("Unable to save given request details"); 
			//e.printStackTrace();
		//	return flag;
		}
		return flag;
	}

	@Transactional
	public RetrieveResultOutput findRequestDetails(RetrieveResultInput retrieveResults) {
		LOGGER.info("Inside findRequestDetails method");
		RetrieveResultOutput rro = new RetrieveResultOutput();
		String leadId = retrieveResults.getLead().getId();
		LeadResult lead = new LeadResult();
		List<Request> reqList = null;
		Employee employee = null;
		Tests test = null;
		lead.setId(leadId);
		List<Ports> portList = null;
		List<Survey> surveyList = null;
		List<Tests> testsList = new ArrayList<Tests>();
		try {
			reqList = requestRepository.findRequestByLead(leadId);
			if (null != reqList) {
				LOGGER.info("Got Request List Details for the given leadId"+reqList);
				for (Request request : reqList) {
					portList = new ArrayList<Ports>();
					surveyList = new ArrayList<Survey>();
					employee = new Employee();
					employee.setName(request.getEmpname());
					employee.setEmailAddress(request.getEmpemailaddress());
					employee.setPhoneNumber(request.getEmpphonenumber());
					test = new Tests();
					String testId = request.getTestid();
					Long reqId = request.getRequest_id();
					Result result = resultRepository.findResultByTest(testId, reqId);
					LOGGER.info("Got Result Details for the testid:"+testId+" resultId:"+reqId);
					test.setId(request.getTestid());
					test.setEmployee(employee);
					test.setDateTime(result.getTestdate());
					test.setIpAddress(result.getClientip());
					test.setUploadBandwidth(result.getBandwidthup());
					test.setDownloadbandwidth(result.getBandwidthdown());
					List<ResultsPorts> portsToTestList = resultsPortsRepository.findResultsPortsByResult(reqId);
					if (null != portsToTestList && portsToTestList.size() > 0) {
						for (ResultsPorts resultPort : portsToTestList) {
							Ports p = new Ports();
							p.setPort(resultPort.getPort_id().toString());
							p.setStatus(resultPort.isStatus() ? "open" : "closed");
							portList.add(p);
						}
					}
					test.setPorts(portList);
					Survey survey = null;
					List<LeadSurveyAnswers> qanda = leadSurveyAnswersRepository.findQAByResult(reqId);
					LOGGER.info("Got LeadSurvey Answers List for the resultId:"+reqId);
					if (null != qanda && qanda.size() > 0) {
						for (LeadSurveyAnswers qa : qanda) {
							survey = new Survey();
							String q = surveyQuestionsRepository.findQById(qa.getQuestion_id());
							LOGGER.info("Question:"+q);
							String a = surveyAnswersRepository.findAnsById(qa.getAnswer_id());
							LOGGER.info("Answer:"+a);
							if (null != q && null != a) {
								survey.setQuestion(q);
								survey.setAnswer(a);
								surveyList.add(survey);
							}
						}
					}
					test.setSurvey(surveyList);
					testsList.add(test);
				}
			}
		} catch (Exception e) {
			LOGGER.info("There is no Request List Details for the given leadId:"+leadId);
			e.printStackTrace();
		}
		rro.setLead(lead);
		rro.setTests(testsList);
		return rro;
	}
	private int hoursDifference(Date date1, Date date2) {
	    final int MILLI_TO_HOUR = 1000 * 60 * 60;
	    return (int) (date1.getTime() - date2.getTime()) / MILLI_TO_HOUR;
	}
	@Transactional
	public List<SurveyQA> getQAByTestDateValidity(String leadid) {
		LOGGER.info("Inside getQAByTestDateValidity");
		List<Timestamp> listreqs = requestRepository.findRequestByLeadTestDate(leadid);
		LOGGER.info("Time Stamp for the given LeadId:"+leadid);
		List<SurveyQA> sqLists = null;
		List<Object[]> result = null;
		if (null != listreqs && !listreqs.isEmpty()) {
			sqLists=new ArrayList<SurveyQA>();
			SimpleDateFormat dateFormat = new SimpleDateFormat("dd MM yyyy HH:mm:ss");
			DateTimeFormatter dateStringFormat = DateTimeFormat.forPattern("dd MM yyyy HH:mm:ss");			
			Date d1=null;
			Date d2=new Date();
			int hours=0;
			try {				
				d1=(Date)listreqs.get(0);
				hours=hoursDifference(d2,d1);
				System.out.println("Hours:"+hours);
			}catch(Exception e){
				LOGGER.info("Unable to parse Date..");
			}

			if (hours <= 72) {
				LOGGER.info("Number of hours for the leadid:"+leadid+" <= "+hours);
				result = surveyQuestionsRepository.findQandA();
				LOGGER.info("Got QandA for the given LeadId:"+leadid);
				if (null != result && !result.isEmpty()) {
					for (Object[] obArr : result) {
						SurveyQA sq = new SurveyQA();
						sq.setQuestion_id((String) obArr[0].toString());
						sq.setQuestion((String) obArr[1].toString());
						sq.setAnswer_id((String) obArr[2].toString());
						sq.setAnswer((String) obArr[3].toString());
						sqLists.add(sq);
					}
				}
			}
		}
		return sqLists;
	}
	@Transactional
	public boolean saveQA(QandAInput qandAInput) {
		LOGGER.info("Inside getQAByTestDateValidity");		
		String testId = null;
		if(null!=qandAInput){
			java.sql.Timestamp ts = java.sql.Timestamp.valueOf(qandAInput.getTestdate());
			System.out.println(ts.toString());
			testId=requestRepository.findRequestByLeadDate(qandAInput.getLeadid(),ts);
			if(null!=testId){
				Result result=new Result();
				result.setTestid(testId);
				result.setTestdate(ts);
				result.setBandwidthup(qandAInput.getBandwidthup());
				result.setBandwidthdown(qandAInput.getBandwidthdown());
				result.setClientip(qandAInput.getClientip());
				result.setLatency(Long.parseLong(qandAInput.getLatency()));
				Result res=resultRepository.save(result);	
				List<Ports> listPorts=qandAInput.getPorts();
				for(Ports port: listPorts){
					PortsToTest ptt=new PortsToTest();
					ptt.setPort_id(Long.parseLong(port.getPort()));
					ResultsPorts resPorts = new ResultsPorts(ptt);									
					resPorts.setResult_id(res.getResult_id());
					//resPorts.setPort_id(Long.parseLong(port.getPort()));
					resPorts.setStatus(Boolean.parseBoolean(port.getStatus()));
					portsToTestRepository.save(ptt);
					LOGGER.info("Port:"+port.getPort()+" is saved successfully");	
					resultsPortsRepository.save(resPorts);					
					LOGGER.info("Result Port:"+res.getResult_id()+" is Saved Succesfully");
				}	
				List<SurveyQAInput> surveyQAList=qandAInput.getSurveyQuestions();
				for(SurveyQAInput surveyQA: surveyQAList){
					LeadSurveyAnswers leadsurveyans=new LeadSurveyAnswers();
					SurveyQuestions surveyQs=new SurveyQuestions();
					SurveyAnswers surveyAs=new SurveyAnswers();
					
					surveyQs.setQuestion_id(Long.parseLong(surveyQA.getQuestionsid()));
					surveyQs.setQuestion(surveyQA.getQuestiontext());
					
					surveyAs.setAnswer_id(Long.parseLong(surveyQA.getAnswerid()));
					surveyAs.setAnswer(surveyQA.getAnswertext());
					
					surveyQuestionsRepository.save(surveyQs);
					surveyAnswersRepository.save(surveyAs);
					LOGGER.info("Survey Question:"+surveyQA.getQuestionsid()+" is saved successfully.");
					LOGGER.info("Survey Answer:"+surveyQA.getAnswerid()+" is saved successfully.");
					leadsurveyans.setResult_id(res.getResult_id());
					leadsurveyans.setQuestion_id(Long.parseLong(surveyQA.getQuestionsid()));
					leadsurveyans.setAnswer_id(Long.parseLong(surveyQA.getAnswerid()));					
					leadSurveyAnswersRepository.save(leadsurveyans);					
					return true;
				}
			}else {
				return false;
			}
		}	
		return false;	
	}
}
